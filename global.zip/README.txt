THIS TEXT CONTAINS ALL COPYRIGHT INFORMATION REGARDING THE PACK:

Credits:

Programer/Original Art Plank Textures were made by Vannila Tweaks

Sounds from Quality Armory plugin but a lot of them are not used.

Villagers as Players models made by SixFootBlue

Some Textures Are From The Space plugin on Spigot

Some Textures are FTF (From the FOG Pack) to see custom entities made by LunarEclipseStudios.
-----------------------------------------------------------------------------------
Links To the Credits:

Vanilla Tweaks: https://vanillatweaks.net/

Quality Armory Plugin: https://www.spigotmc.org/resources/quality-armory.47561/

SixFootBlues Villager to Player Models Pack: https://www.curseforge.com/minecraft/texture-packs/player-villager-models

Space Plugin: https://www.spigotmc.org/resources/space.59572/

From The Fog: https://github.com/LunarEclipseStudios/From-The-Fog
---------------------------------------------------------------------------------

ANY MODIFICATIONS THAT ARE DIFFRENT THEN THESE PACKS WERE MADE BY Stanexir

The Pack also contains all mojang textures with some changes that bring back some old textures or some small changes.

THIS PACK IS ONLY MADE FOR THE NOVA SOLVARIS MINECRAFT SERVER PLEASE DO NOT USE IT OUTSIDE OF IT.